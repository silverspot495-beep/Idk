package com.kamo.overlay;

import com.mojang.brigadier.arguments.FloatArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class KamoClient implements ClientModInitializer {
    private static boolean visible = true;
    private static boolean previousToggleDown = false;
    private static float scale = 1.0f;

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("kamo")
                .then(ClientCommandManager.literal("scale")
                    .then(ClientCommandManager.argument("scale", FloatArgumentType.floatArg(0.1f, 1.0f))
                        .executes(context -> {
                            scale = FloatArgumentType.getFloat(context, "scale");
                            context.getSource().sendFeedback(
                                net.minecraft.text.Text.literal(String.format("KAMO scale set to %.1f", scale)));
                            return 1;
                        })))));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getWindow() == null) return;
            boolean down = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_O) == GLFW.GLFW_PRESS;
            if (down && !previousToggleDown) {
                visible = !visible;
                if (client.player != null) {
                    client.player.sendMessage(
                        net.minecraft.text.Text.literal("KAMO overlay: " + (visible ? "ON" : "OFF")), true);
                }
            }
            previousToggleDown = down;
        });

        HudElementRegistry.addLast(Identifier.of("kamo", "keystrokes"),
            (context, tickCounter) -> {
                MinecraftClient client = MinecraftClient.getInstance();
                if (!visible || client.player == null || client.options.hudHidden) return;
                renderOverlay(context, client);
            });
    }

    private static void renderOverlay(DrawContext context, MinecraftClient client) {
        long handle = client.getWindow().getHandle();
        context.getMatrices().push();
        context.getMatrices().scale(scale, scale, 1.0f);

        final int x = 5, key = 20, gap = 2;
        int row1 = 5;
        int row2 = row1 + key + gap;
        int row3 = row2 + key + gap;
        int row4 = row3 + key + gap;
        int row5 = row4 + key + gap;

        // Original KAMO layout: number row, QWERTY, home row, lower row, modifiers.
        int px = x + 10;
        String[] top = {"~", "1", "2", "3", "4", "5"};
        int[] topCodes = {96, 49, 50, 51, 52, 53};
        for (int i = 0; i < top.length; i++) {
            drawKey(context, client, handle, px + i * (key + gap), row1,
                key, key, top[i], topCodes[i]);
        }

        drawKey(context, client, handle, x + 5, row2, 30, key, "TAB", GLFW.GLFW_KEY_TAB);
        String[] upper = {"Q", "W", "E", "R", "T"};
        int[] upperCodes = {81, 87, 69, 82, 84};
        for (int i = 0; i < upper.length; i++) {
            drawKey(context, client, handle, x + 37 + i * (key + gap), row2,
                key, key, upper[i], upperCodes[i]);
        }

        String[] home = {"A", "S", "D", "F", "G"};
        int[] homeCodes = {65, 83, 68, 70, 71};
        for (int i = 0; i < home.length; i++) {
            drawKey(context, client, handle, x + 5 + i * (key + gap), row3,
                key, key, home[i], homeCodes[i]);
        }

        drawKey(context, client, handle, x + 5, row4, 35, key, "SHIFT", GLFW.GLFW_KEY_LEFT_SHIFT);
        String[] lower = {"Z", "X", "C", "V", "B"};
        int[] lowerCodes = {90, 88, 67, 86, 66};
        for (int i = 0; i < lower.length; i++) {
            drawKey(context, client, handle, x + 42 + i * (key + gap), row4,
                key, key, lower[i], lowerCodes[i]);
        }

        drawKey(context, client, handle, x + 5, row5, 30, key, "CTRL", GLFW.GLFW_KEY_LEFT_CONTROL);
        drawKey(context, client, handle, x + 37, row5, 30, key, "ALT", GLFW.GLFW_KEY_LEFT_ALT);
        drawKey(context, client, handle, x + 69, row5, 64, key, "SPACE", GLFW.GLFW_KEY_SPACE);

        int mouseX = x + 10;
        int mouseY = row5 + key + 4;
        boolean left = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        drawBox(context, client, mouseX, mouseY, 32, 35, "LMB", left);
        drawBox(context, client, mouseX + 32, mouseY, 32, 35, "RMB", right);
        drawBox(context, client, mouseX, mouseY + 37, 64, 40, "", false);

        context.getMatrices().pop();
    }

    private static void drawKey(DrawContext context, MinecraftClient client, long window,
                                int x, int y, int width, int height, String label, int code) {
        boolean pressed = code >= 0 && GLFW.glfwGetKey(window, code) == GLFW.GLFW_PRESS;
        drawBox(context, client, x, y, width, height, label, pressed);
    }

    private static void drawBox(DrawContext context, MinecraftClient client,
                                int x, int y, int width, int height, String label, boolean pressed) {
        int background = pressed ? 0xCC7B7B7B : 0x4D000000;
        context.fill(x, y, x + width, y + height, background);
        if (!label.isEmpty()) {
            int textWidth = client.textRenderer.getWidth(label);
            int textX = x + (width - textWidth) / 2;
            int textY = y + (height - 8) / 2;
            context.drawText(client.textRenderer, label, textX, textY, 0xFFFFFF, false);
        }
    }
}
