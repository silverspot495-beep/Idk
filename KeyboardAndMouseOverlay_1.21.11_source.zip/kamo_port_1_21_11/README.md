# Keyboard And Mouse Overlay (KAMO) — Minecraft 1.21.11 port source

This project updates the original Fabric client mod's metadata and HUD integration for Minecraft 1.21.11.

## Preserved overlay layout
- `~`, number keys 1–5
- TAB and QWERTY row
- ASDFG home row
- SHIFT and ZXCVB row
- CTRL, ALT and SPACE
- LMB / RMB indicators
- `O` toggles the overlay
- `/kamo scale <0.1–1.0>` changes the overlay scale

## Build
Requires Java 21 and a compatible Gradle installation, plus internet access so Gradle can download Minecraft, Fabric Loom, Fabric Loader and Fabric API.

From this folder run:

```sh
gradle build
```

The remapped mod JAR should be created in `build/libs/`.

## Important
This is a source project, not a compiled JAR. It could not be compiled in this environment because outbound network/DNS access to the Fabric Maven repository is unavailable. The source and dependency versions should be compiled and tested before installing it in a game.
